package com.example.letradnimodificado.ui;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.letradnimodificado.core.CalcularDni;


public class MainActivity extends AppCompatActivity {

    private EditText edDni;
    private TextView viewText2;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }


    public void calcularLetra(View view) {
        edDni=findViewById(R.id.edDni);
        viewText2=findViewById(R.id.lblResult);

        if(edDni.getText().toString().length()<8) {
            viewText2.setText("Error DNI incorrecto");
        

        }else{
            int dni = Integer.parseInt(edDni.getText().toString());

            char letra = CalcularDni.calcula(dni);


            viewText2.setText(Character.toString(letra));
        }

        return;
    }
}
