package com.example.calculararea.core;

public class CalcularArea {
    public static float calcula(float num1,float num2){
        float area=0;


        return area=num1*num2;
    }

}

