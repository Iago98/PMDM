package com.example.calculararea.ui;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.calculararea.core.CalcularArea;

public class MainActivity  extends AppCompatActivity {

    private TextView lblResult;
    private EditText val1;
    private EditText val2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        val1 = (EditText) this.findViewById(R.id.val1);
        val1.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View arg0, int arg1, KeyEvent arg2) {

                MainActivity.this.calcula();
                return false;
            }
        });
        val2 = (EditText) this.findViewById(R.id.val2);
        val2.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View arg0, int arg1, KeyEvent arg2) {

                MainActivity.this.calcula();
                return false;
            }
        });
    }

    public static boolean isNumber(String cad) {
        boolean bool;
        try {
            Float.parseFloat(cad);
            bool = true;
        } catch (NumberFormatException e) {
            bool = false;
        }
        return bool;
    }

    protected void calcula() {
        lblResult = findViewById(R.id.lblResult);

        float val1Int;
        float val2Int;

        //meter en el if el isnumber para q se repita el bucle
        if ((isNumber(val1.getText().toString())== true) && (isNumber(val2.getText().toString()) == true)) {
            val1Int = Float.parseFloat(val1.getText().toString());
            val2Int = Float.parseFloat(val2.getText().toString());
            float suma = CalcularArea.calcula(val1Int, val2Int);
            lblResult.setText(Float.toString(suma) + " m2");
        }
        else if((isNumber(val1.getText().toString())== false) && (isNumber(val2.getText().toString()) == false)) {
            lblResult.setText(R.string.label_default_result_vacio2);

        }else {
            lblResult.setText(R.string.label_default_result_vacio);


        }
    }
}
