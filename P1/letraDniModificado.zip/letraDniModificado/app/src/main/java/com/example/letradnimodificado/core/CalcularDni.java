package com.example.letradnimodificado.core;

public class CalcularDni {

    public static final String NIF_STRING_ASSOCIATION= "TRWAGMYFPDGBMJZSQVHLCKE";

    public static char calcula(int dni){

        return NIF_STRING_ASSOCIATION.charAt(dni % 23);


    }

}