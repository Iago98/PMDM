package com.example.calculararea.core;

public class CalcularArea {
    public static int calcula(int num1,int num2){
        int area=0;


        return area=num1*num2;
    }

}

