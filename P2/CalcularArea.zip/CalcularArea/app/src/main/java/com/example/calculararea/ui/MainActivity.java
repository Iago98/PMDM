package com.example.calculararea.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.calculararea.core.CalcularArea;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private TextView lblResult;
    private EditText val1;
    private EditText val2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcularArea (View view){
        lblResult=findViewById(R.id.lblResult);
        val1=findViewById(R.id.val1);
        val2=findViewById(R.id.val2);

        int val1Int = Integer.parseInt(val1.getText().toString());
        int val2Int = Integer.parseInt(val2.getText().toString());

        int suma= CalcularArea.calcula(val1Int,val2Int);

        lblResult.setText(Integer.toString(suma)+" m^2");
        return;


    }


}
